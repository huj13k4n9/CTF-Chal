const puppeteer = require("puppeteer");
const Redis = require('ioredis');
const connection = new Redis(6379, process.env.REDIS_HOST ?? "127.0.0.1");

const browser_option = {
    headless: true,
    args: [
        '--no-sandbox',
        '--disable-gpu',
        '--js-flags="--noexpose_wasm --jitless"',
    ],
    executablePath: "google-chrome-stable"
};

const MAIN_SITE = process.env.MAIN_SITE ?? "http://127.0.0.1:8000"
const FLAG = process.env.FLAG ?? "flag{test}"

const sleep = (delay) => {
    return new Promise((resolve) => setTimeout(resolve, delay))
}

async function browse(url) {

    console.log(`[+] browsing ${url} started`)

    const browser = await puppeteer.launch(browser_option);
    const page = await browser.newPage();

    page.on('dialog', async (dialog) => {
        await dialog.dismiss();
    });

    try {

        await page.goto(MAIN_SITE, { timeout: 3000, waitUntil: 'domcontentloaded' });
        await sleep(1000);

        await page.setCookie({
            name: "FLAG",
            value: FLAG,
            domain: new URL(MAIN_SITE).hostname,
            path: "/",
            secure: false,
            httpOnly: true
        });

        await page.goto(url, { timeout: 3000, waitUntil: 'domcontentloaded' });
        await sleep(5000);

    } catch (err) {
        console.log(err);
    } finally {
        await page.close();
        await browser.close();
    }

    console.log(`[+] browsing ${url} finished`)
}

const handler = async () => {
    console.log('[+] Starting bot');

    while (true) {
	console.log("[+] Working ")
        connection.blpop('urls', 0, async (err, message) => {
            try {
                let url = message[1];
                let parsed = new URL(url);
                if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
                    throw new Error('Invalid protocol');
                } else {
                    console.log('[+] Visiting ' + url);
                    await browse(url);
                }
                await sleep(3000);
            } catch (e) { }
        });
        await sleep(3000)
    }
}

handler();
