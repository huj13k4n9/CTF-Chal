// used to solve the pow problem when submitting url to bot
// g++ -O3 -march=native -lcrypto -pthread pow.cpp -o pow-solver
// ./pow-solver <6-digits-prefix>

#include <iostream>
#include <sstream>
#include <chrono>
#include <vector>
#include <thread>
#include <mutex>
#include <cstring>
#include <iomanip>
#include <openssl/sha.h>
#include <algorithm>
const int MAX_DIGITS = 20; // Maximum number of digits to check
const int NUM_THREADS = 4; // Number of threads to use

std::mutex g_last_proof_mutex;
std::string g_last_proof = "000000"; // Proof of work found by previous thread(s)
bool g_found_proof = false; // Flag indicating whether a proof of work has been found

void sha256(const std::string& input, unsigned char output[SHA256_DIGEST_LENGTH]) {
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, input.c_str(), input.size());
    SHA256_Final(output, &sha256);
}

bool check_proof(const std::string& proof, const std::string& prefix) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    sha256(proof, hash);

    std::stringstream ss;
    ss << std::hex << std::setw(2) << std::setfill('0') << std::nouppercase;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        ss << static_cast<int>(hash[i]);
    }

    std::string hash_str = ss.str();
    std::transform(hash_str.begin(), hash_str.end(), hash_str.begin(), ::tolower);
    return hash_str.substr(0, prefix.size()) == prefix;
}
void brute_force(int start, int end, const std::string& prefix) {
    std::string last_proof = g_last_proof;
    std::string proof;

    for (int num = start; num <= end && !g_found_proof; num++) {
        std::ostringstream oss;
        oss << num;
        std::string num_str = oss.str();

        proof = last_proof + std::string(MAX_DIGITS - num_str.size(), '0') + num_str;

        if (check_proof(proof, prefix)) {
            std::lock_guard<std::mutex> lock(g_last_proof_mutex);
            if (!g_found_proof) {
                std::cout << "Thread " << std::this_thread::get_id() << " found a proof of work: " << proof << std::endl;
                g_last_proof = proof;
                g_found_proof = true;
            }
            return;
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " PREFIX" << std::endl;
        return 1;
    }

    std::string prefix = argv[1];
    if (prefix.size() != 6 || prefix.find_first_not_of("0123456789abcdef") != std::string::npos) {
        std::cerr << "Invalid prefix: " << prefix << std::endl;
        return 1;
    }

    std::vector<std::thread> threads;
    auto start_time = std::chrono::steady_clock::now();

    for (int i = 0; i < NUM_THREADS; i++) {
        threads.emplace_back(brute_force, i * (1000000000 / NUM_THREADS) + 1, (i + 1) * (1000000000 / NUM_THREADS), prefix);
    }

    for (std::thread& t : threads) {
        t.join();
    }

    auto end_time = std::chrono::steady_clock::now();
    auto elapsed_time = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();

    std::cout << "Elapsed time: " << elapsed_time / 1000.0 << " s" << std::endl;

    return 0;
}