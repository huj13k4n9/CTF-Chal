use rocket::response::Redirect;
use rocket_dyn_templates::Template;

mod playlist;
mod report;
mod user;
mod utils;

#[macro_use]
extern crate rocket;
#[macro_use]
extern crate lazy_static;

#[get("/")]
fn index() -> Redirect {
    Redirect::to(uri!("/playlist"))
}

#[rocket::main]
async fn main() -> Result<(), rocket::Error> {
    utils::initialize().await;

    rocket::tokio::spawn(async {
        loop {
            // reinitialize every 15min
            rocket::tokio::time::sleep(std::time::Duration::from_secs(60 * 15)).await;
            utils::initialize().await;
        }
    });

    let _rocket = rocket::build()
        .mount("/", routes![index])
        .attach(user::stage())
        .attach(playlist::stage())
        .attach(report::stage())
        .attach(Template::fairing())
        .register("/", catchers![user::not_authorized_redirect])
        .launch()
        .await?;

    Ok(())
}
