use std::{error::Error, thread};

use form_urlencoded::Serializer;
use headless_chrome::{
    browser::{
        tab::{RequestInterceptionDecision, RequestInterceptor},
        LaunchOptionsBuilder,
    },
    protocol::network::methods::RequestPattern,
    Browser,
};
use rocket::{
    http::Header,
    response::{self, status::Forbidden, Flash, Redirect, Responder},
    Request, Response,
};
use rocket_dyn_templates::{context, Template};
use url::Url;

use crate::{
    playlist::PLAYLIST_HASHMAP,
    user::AuthorizedUser,
    utils::{ADMIN_PASSWORD, ADMIN_USERNAME, NETLOC},
};

struct TemplateWithCSP {
    csp: &'static str,
    template: Template,
}

impl<'r, 'o> Responder<'r, 'o> for TemplateWithCSP
where
    'o: 'r,
{
    fn respond_to(self, request: &Request<'_>) -> response::Result<'o> {
        let mut response = Response::build();
        response.merge(self.template.respond_to(request)?);
        response.header(Header::new("Content-Security-Policy", self.csp));
        response.ok()
    }
}

#[get("/audit?<target>")]
async fn report_audit(
    user: AuthorizedUser,
    target: String,
) -> Result<TemplateWithCSP, Forbidden<&'static str>> {
    if user.username != ADMIN_USERNAME.as_str() {
        return Err(Forbidden(Some("You are not admin!")));
    }

    let playlist_map = PLAYLIST_HASHMAP.read().await;
    let playlist = playlist_map.get(&target);

    const CSP: &'static str = "sandbox allow-scripts allow-same-origin; default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:; media-src data:; form-action 'none'; frame-ancestors 'none'; base-uri 'none';";

    if let Some(playlist) = playlist {
        return Ok(TemplateWithCSP {
            csp: CSP,
            template: Template::render(
                "audit",
                context! {
                    playlist
                },
            ),
        });
    } else {
        return Ok(TemplateWithCSP {
            csp: CSP,
            template: Template::render(
                "audit",
                context! {
                    playlist: &Vec::<String>::new()
                },
            ),
        });
    };
}

#[post("/")]
fn report_index(user: AuthorizedUser) -> Flash<Redirect> {
    let username = user.username;

    thread::spawn(|| {
        if let Err(result) = dispatch_task(username) {
            println!("audit error: {}", result);
        }
    });

    return Flash::success(Redirect::to(uri!("/playlist")), "Your report dispatched");
}

fn dispatch_task(username: String) -> Result<(), Box<dyn Error>> {
    let options = LaunchOptionsBuilder::default().headless(true).build()?;
    let browser = Browser::new(options)?;
    let tab = browser.wait_for_initial_tab()?;

    tab.navigate_to(&format!("http://{}/", NETLOC.as_str()))?;

    tab.wait_for_element("input#username")?.click()?;
    tab.type_str(&ADMIN_USERNAME)?;

    tab.wait_for_element("input#password")?.click()?;
    tab.type_str(&ADMIN_PASSWORD)?.press_key("Enter")?;
    thread::sleep(std::time::Duration::from_secs_f32(0.5f32));

    let mut audit_url = String::from(&format!("http://{}/report/audit?", NETLOC.as_str()));
    audit_url.push_str(
        &Serializer::new(String::new())
            .append_pair("target", &username)
            .finish(),
    );

    // don't try to steal my secret!
    let interceptor: RequestInterceptor = Box::new(|_transport, _session_id, interception| {
        println!("{}", &interception.request.url);

        let url = Url::parse(&interception.request.url);
        return if let Ok(url) = url {
            let mut request_netloc = String::new();
            let host = url.host();
            let port = url.port();

            if host.is_some() {
                request_netloc.push_str(&host.unwrap().to_string());

                if port.is_some() {
                    request_netloc.push(':');
                    request_netloc.push_str(&port.unwrap().to_string());
                }
            }

            if NETLOC.eq(&request_netloc) && url.path() == "/report/audit" {
                RequestInterceptionDecision::Continue
            } else {
                RequestInterceptionDecision::Response(String::from(base64::encode(
                    "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n",
                )))
            }
        } else {
            RequestInterceptionDecision::Response(String::new())
        };
    });

    tab.enable_request_interception(
        &[RequestPattern {
            url_pattern: None,
            resource_type: None,
            interception_stage: Some("Request"),
        }],
        interceptor,
    )?;

    tab.navigate_to(&audit_url)?;
    thread::sleep(std::time::Duration::from_secs(8));
    Ok(())
}

pub fn stage() -> rocket::fairing::AdHoc {
    rocket::fairing::AdHoc::on_ignite("Report", |rocket| async {
        rocket.mount("/report", routes![report_audit, report_index])
    })
}
