use regex::Regex;
use rocket::form::Form;
use rocket::tokio::sync::RwLock;
use rocket::{
    fs::TempFile,
    request::FlashMessage,
    response::{Flash, Redirect},
};
use rocket_dyn_templates::{context, Template};
use std::collections::HashMap;
use std::fs;

use crate::user::AuthorizedUser;

#[derive(FromForm, Debug)]
pub struct UploadMusic<'r> {
    #[field(validate = len(3..))]
    pub name: String,

    #[field(validate = len(3..))]
    pub author: String,

    pub description: String,
    pub music: TempFile<'r>,
}

#[derive(FromForm)]
pub struct DeleteMusic {
    index: usize,
}

type PackedMusic = String;
type Playlist = Vec<PackedMusic>;

fn read_tempfile(tempfile: &TempFile) -> Vec<u8> {
    return match tempfile {
        TempFile::Buffered { content } => content.bytes().collect::<Vec<u8>>(),
        TempFile::File { path, .. } => {
            return if let Ok(content) = fs::read(path) {
                content
            } else {
                Vec::new()
            };
        }
    };
}

lazy_static! {
    static ref MARKDOWN_REGEX: [(Regex, &'static str); 6] = [
        (Regex::new(r"\n{2}|(?:\r\n){2}").unwrap(), "<br>"),
        (Regex::new(r"\*\*([^\s<>]+)\*\*").unwrap(), "<b>${1}</b>"),
        (Regex::new(r"__([^\s<>]+)__").unwrap(), "<b>${1}</b>"),
        (Regex::new(r"\*([^\s<>]+)\*").unwrap(), "<em>${1}</em>"),
        (Regex::new(r"_([^\s<>]+)_").unwrap(), "<em>${1}</em>"),
        (
            Regex::new(r"!\[\]\((data:image/png;base64,[A-Za-z0-9+/=]+)\)").unwrap(),
            "<img src='${1}'>"
        )
    ];
}

fn process_description(description: &String) -> String {
    let mut description = html_escape::encode_quoted_attribute(description).to_string();
    for regex in MARKDOWN_REGEX.iter() {
        description = regex
            .0
            .replace_all(description.as_str(), regex.1)
            .to_string();
    }
    return description;
}

impl Into<PackedMusic> for UploadMusic<'_> {
    fn into(self) -> PackedMusic {
        let mut packed_music = String::new();

        let mut append_string = |s: &String| {
            packed_music.push_str(&s.chars().count().to_string());
            packed_music.push('|');
            packed_music.push_str(&s);
        };

        append_string(&self.name);
        append_string(&self.author);
        append_string(&process_description(&self.description));

        let mut music_content = base64::encode(read_tempfile(&self.music));
        music_content.insert_str(0, "data:audio/mp3;base64,");
        append_string(&music_content);

        return packed_music;
    }
}

lazy_static! {
    pub static ref PLAYLIST_HASHMAP: RwLock<HashMap<String, Playlist>> =
        RwLock::new(HashMap::new());
}

#[get("/")]
async fn playlist_index(user: AuthorizedUser, flash: Option<FlashMessage<'_>>) -> Template {
    let username = &user.username;
    let playlist_map = PLAYLIST_HASHMAP.read().await;
    let playlist = playlist_map.get(username).unwrap();

    let flash = flash.map(FlashMessage::into_inner);
    Template::render(
        "playlist",
        context! {
            flash,
            playlist
        },
    )
}

#[post("/add", data = "<music>")]
async fn playlist_add(user: AuthorizedUser, music: Form<UploadMusic<'_>>) -> Flash<Redirect> {
    println!("{:?}", music);

    let username = &user.username;
    PLAYLIST_HASHMAP
        .write()
        .await
        .get_mut(username)
        .unwrap()
        .push(music.into_inner().into());
    return Flash::success(Redirect::to(uri!("/playlist")), "Add success");
}

#[post("/delete", data = "<delete_music>")]
async fn playlist_delete(user: AuthorizedUser, delete_music: Form<DeleteMusic>) -> Flash<Redirect> {
    let username = &user.username;
    let mut playlist_map = PLAYLIST_HASHMAP.write().await;
    let playlist = playlist_map.get_mut(username).unwrap();

    if playlist.len() > delete_music.index {
        playlist.remove(delete_music.index);
        return Flash::success(Redirect::to(uri!("/playlist")), "Delete success");
    } else {
        return Flash::success(Redirect::to(uri!("/playlist")), "Delete failed");
    }
}

pub fn stage() -> rocket::fairing::AdHoc {
    rocket::fairing::AdHoc::on_ignite("Playlist", |rocket| async {
        rocket.mount(
            "/playlist",
            routes![playlist_index, playlist_add, playlist_delete],
        )
    })
}
