use std::path::PathBuf;

use rocket::fs::TempFile;

use crate::{
    playlist::{UploadMusic, PLAYLIST_HASHMAP},
    user::{User, SESSION_HASHMAP, USER_HASHMAP},
};

lazy_static! {
    pub static ref ADMIN_USERNAME: String = String::from("admin");
    pub static ref ADMIN_PASSWORD: String =
        std::env::var("ADMIN_PASSWORD").expect("Please set env ADMIN_PASSWORD");
    static ref FLAG: String = std::env::var("FLAG").expect("Please set env FLAG");
    pub static ref NETLOC: String = std::env::var("NETLOC").expect("Please set env NETLOC");
}

pub async fn initialize() {
    let mut user_map = USER_HASHMAP.write().await;
    let mut session_map = SESSION_HASHMAP.write().await;
    let mut playlist_map = PLAYLIST_HASHMAP.write().await;

    user_map.clear();
    session_map.clear();
    playlist_map.clear();

    user_map.insert(
        ADMIN_USERNAME.clone(),
        User::from_userpass(&ADMIN_USERNAME, &ADMIN_PASSWORD),
    );
    playlist_map.insert(
        ADMIN_USERNAME.clone(),
        vec![UploadMusic {
            name: "flag".to_string(),
            author: "flag".to_string(),
            description: format!(
                "Congratulations, here is your flag!\n\n**{}**",
                FLAG.to_string()
            ),
            music: TempFile::File {
                file_name: None,
                content_type: None,
                path: rocket::Either::Right(PathBuf::from("./never_gonna_give_you_up.mp3")),
                len: 0,
            },
        }
        .into()],
    );
}
