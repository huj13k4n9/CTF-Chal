use crate::playlist::PLAYLIST_HASHMAP;
use rocket::form::Form;
use rocket::response::{Flash, Redirect};
use rocket::tokio::sync::RwLock;
use rocket::{
    http::{Cookie, CookieJar, SameSite, Status},
    request::{FlashMessage, FromRequest, Outcome},
    Request,
};
use rocket_dyn_templates::{context, Template};
use sha256::digest;
use std::collections::HashMap;
use uuid::Uuid;

#[derive(FromForm, Clone)]
pub struct User {
    #[field(validate = len(5..32))]
    username: String,

    #[field(validate = len(5..32))]
    password: String,
}

impl User {
    pub fn from_userpass(username: &String, password: &String) -> Self {
        User {
            username: username.clone(),
            password: digest(password),
        }
    }

    pub fn verify_password(&self, password: &String) -> bool {
        return self.password == digest(password);
    }

    pub fn get_username(&self) -> String {
        return self.username.clone();
    }
}

lazy_static! {
    pub static ref USER_HASHMAP: RwLock<HashMap<String, User>> = RwLock::new(HashMap::new());
    pub static ref SESSION_HASHMAP: RwLock<HashMap<String, String>> = RwLock::new(HashMap::new());
}

static SESSION_NAME: &str = "session";

pub struct AuthorizedUser {
    pub username: String,
}

#[derive(Debug)]
pub struct AuthorizeError;

#[rocket::async_trait]
impl<'r> FromRequest<'r> for AuthorizedUser {
    type Error = AuthorizeError;

    async fn from_request(req: &'r Request<'_>) -> Outcome<Self, Self::Error> {
        match req.cookies().get(SESSION_NAME) {
            None => Outcome::Failure((Status::Unauthorized, AuthorizeError)),
            Some(cookie) => {
                return if let Some(username) = SESSION_HASHMAP.read().await.get(cookie.value()) {
                    Outcome::Success(AuthorizedUser {
                        username: username.clone(),
                    })
                } else {
                    Outcome::Failure((Status::Unauthorized, AuthorizeError))
                }
            }
        }
    }
}

#[get("/")]
fn user_index(flash: Option<FlashMessage<'_>>) -> Template {
    let flash = flash.map(FlashMessage::into_inner);

    Template::render(
        "user",
        context! {
            flash
        },
    )
}

#[post("/login", data = "<user>")]
async fn user_login(user: Form<User>, cookies: &CookieJar<'_>) -> Flash<Redirect> {
    if let Some(real_user) = USER_HASHMAP.read().await.get(&user.username) {
        if real_user.verify_password(&user.password) {
            let session_id = Uuid::new_v4().to_string();
            SESSION_HASHMAP
                .write()
                .await
                .insert(session_id.clone(), real_user.get_username());
            cookies.add(
                Cookie::build(SESSION_NAME, session_id)
                    .same_site(SameSite::Strict)
                    .finish(),
            );
            return Flash::success(Redirect::to(uri!("/playlist")), "Login success");
        }
    }
    return Flash::error(
        Redirect::to(uri!("/user")),
        "User not exists or password error",
    );
}

#[post("/register", data = "<user>")]
async fn user_register(user: Form<User>) -> Flash<Redirect> {
    let mut user_map = USER_HASHMAP.write().await;

    return if user_map.contains_key(&user.username) {
        Flash::error(Redirect::to(uri!("/user")), "User already exists")
    } else {
        let mut playlist_map = PLAYLIST_HASHMAP.write().await;
        playlist_map.insert(user.username.clone(), Vec::new());

        user_map.insert(
            user.username.clone(),
            User::from_userpass(&user.username, &user.password),
        );
        Flash::success(Redirect::to(uri!("/user")), "Register done")
    };
}

pub fn stage() -> rocket::fairing::AdHoc {
    rocket::fairing::AdHoc::on_ignite("User", |rocket| async {
        rocket.mount("/user", routes![user_index, user_login, user_register])
    })
}

#[catch(401)]
pub fn not_authorized_redirect(_: &Request) -> Flash<Redirect> {
    Flash::error(Redirect::to(uri!("/user")), "Your session is expired, please relogin")
}
