const { app, BrowserWindow, ipcMain, dialog } = require('electron')
const path = require('path')

function createWindow (openUrl, savePath) {
    const window = new BrowserWindow({
        width: 800,
        height: 600,
        webPreferences: {
            nodeIntegration: false,
            contextIsolation: false,
            webviewTag: false,
            devTools: false,
            preload: path.join(__dirname, 'preload.js')
        }
    })

    ipcMain.handle('saveLog', async (event) => {
        if (savePath !== null && typeof savePath == 'string') {
            return savePath;
        }

        let result = await dialog.showSaveDialog({ properties: ['openFile'] })
        if (!result.canceled) {
            return result.filePath;
        } else {
            return null;
        }
    })

    window.removeMenu()
    window.loadURL(openUrl);
}

app.whenReady().then(() => {
    let openUrl = "http://124.16.75.162:31023/"
    let savePath = null;

    if (process.argv.length === 3) { // Some hook for admin
        openUrl = process.argv[1];
        savePath = process.argv[2];
        setTimeout(function () {
            app.exit(0)
        }, 5000)
    }

    createWindow(openUrl, savePath);

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow()
        }
    })
})

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit()
    }
})
