const express = require("express");
const child_process = require("child_process");

let app = express();

app.get('/visit', function (req, res){
    let id = req.query.id;
    if (typeof id === "string" && id.match(/^[0-9a-z-]{36}$/) !== null) {
        child_process.execFile("/app/dist/linux-unpacked/brave-client", [`http://server/?id=${id}`, "/tmp/save"], {env: {'DISPLAY': ':99.0'}})
    }
    res.json({ok: true})
});

app.listen(8000);
console.log('Server is listening on port 8000');
