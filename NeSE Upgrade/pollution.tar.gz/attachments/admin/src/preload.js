const fs = require('fs')
const { ipcRenderer } = require('electron')

window.saveLog = async function () {
    let path = await ipcRenderer.invoke("saveLog", {})
    if (path !== null && typeof path === "string") {
        fs.writeFileSync(path, $("#battle_info").innerText);
    }
}

window.isBraveClient = true;
