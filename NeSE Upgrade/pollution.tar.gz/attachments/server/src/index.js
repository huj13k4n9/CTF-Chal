let express = require('express');
let cookieParser = require('cookie-parser');
let uuid = require('uuid');
let chroot = require('chroot');
let http = require('http');

let app = express();

app.set('view engine', 'ejs');
app.use(cookieParser())
app.locals.compileDebug = false;

app.use(function (req, res, next) {
    res.header({
        "X-Frame-Options": "DENY",
        "Content-Security-Policy": "default-src 'none'; connect-src 'self'; style-src 'unsafe-inline'; script-src 'sha256-SPnZvPOuNtRS5fYSINjqhk7q8o7NmjaExqk02ncxx8Q=' 'sha256-MIMje86cIaYGhwD2ZpZmPWn24r27f6xHrBCFkVPwnMU='"
    });
    next();
});

const BraveStatus = {
    Living: "Living",
    Dead: "Dead",
}

class Brave {
    name

    health
    attack
    defence

    status
    score
    experience
    level

    constructor(setting) {
        this.name = setting.name;
        this.health = Number(setting.healthPoint) * 10;
        this.attack = Number(setting.attackPoint);
        this.defence = Number(setting.defencePoint);
        this.status = BraveStatus.Living;
        this.score = 0;
        this.experience = 0;
        this.level = 1;
    }

    levelUp(experience) {
        let nextLevelExperience = (2**this.level);
        this.experience += experience;
        if (this.experience >= nextLevelExperience) {
            this.level++;
            this.experience -= nextLevelExperience;
            this.health += Math.floor(Math.random() * 10 * this.level);
            this.attack += 3;
            this.defence += 3;
            return `Level up! Your current in level [${this.level}]`
        } else {
            return `Current experience [${this.experience} / ${nextLevelExperience}]`
        }
    }

    battle(monster) {
        function calcDamage(attack, defence) {
            if (attack > defence) {
                return attack - defence;
            } else {
                return 1;
            }
        }

        let battleLog = [];
        // brave always attack first

        battleLog.push(`You meet monster [${monster.name}]!`)

        while (monster.health > 0) {
            let damage = calcDamage(this.attack, monster.defence);
            monster.health = monster.health - damage;
            battleLog.push(`You attack [${monster.name}] and make [${damage}] damage, [${monster.name}] remain [${monster.health}] health`);

            damage = calcDamage(monster.attack, this.defence);
            this.health = this.health - damage;
            battleLog.push(`[${this.name}] get [${damage}] damaged by [${monster.name}], remain ${this.health} health`);

            if (this.health <= 0) {
                battleLog.push(`You dead! Final score is ${this.score}`);
                this.status = BraveStatus.Dead;
                break;
            }

            if (monster.health <= 0) {
                this.score += monster.experience;
                battleLog.push(`You beat [${monster.name}] and get [${monster.experience}] experience`);
                battleLog.push(this.levelUp(monster.experience));
                break;
            }
        }
        return battleLog;
    }
}

class Monster {
    name
    health
    attack
    defence
    experience

    constructor(name, health, attack, defence, experience) {
        this.name = name;
        this.health = health;
        this.attack = attack;
        this.defence = defence;
        this.experience = experience;
    }
}

let availableMonster = [
    new Monster('Mornfoot', 10, 10, 10, 1),
    new Monster('Grimespawn', 30, 30, 10, 5),
    new Monster('Bouldergolem', 25, 20, 30, 5),
    new Monster('Hauntmouth', 40, 5, 60, 10),
    new Monster('The Nasty Screamer', 20, 50, 5, 10),
];

class Response {
    code
    msg
    payload

    constructor(code, msg='', payload=null) {
        this.code = code;
        this.msg = msg;
        this.payload = payload;
    }
}

function randomChoice(arr) {
    return arr[Math.floor(arr.length * Math.random())];
}

let defaultSetting = {
    name: "Brave",
    healthPoint: 20,
    attackPoint: 20,
    defencePoint: 20,
};

let maxPointSum = 60;

let sessions = {};
let sessionExpire = 1800 * 1000; // half hour

let mergeObject = function (from, to) {
    for (let prop of Object.keys(from)) {
        if (typeof to[prop] === 'object' && to[prop] !== null) {
            to[prop] = mergeObject(from[prop], to[prop]);
        } else {
            if (typeof from[prop] === 'object' && from[prop] !== null) {
                to[prop] = mergeObject(from[prop], {});
            } else {
                to[prop] = from[prop];
            }
        }
    }
    return to
}

app.get('/', function(req, res) {
    res.render('index');
});

app.get('/setting', function(req, res) {
    res.render('setting', {cookie: req.cookies});
});

app.get('/api/start', function(req, res) {
    let userSetting = mergeObject(req.cookies, mergeObject(defaultSetting, {}));

    function checkValue(val) {
        let num = Number(val);
        return num.toString() === val.toString() && num > 0;
    }

    if (checkValue(userSetting.healthPoint) && checkValue(userSetting.attackPoint) && checkValue(userSetting.defencePoint)
        && (Number(userSetting.healthPoint) + Number(userSetting.attackPoint) + Number(userSetting.defencePoint)) <= maxPointSum) {
        let id = uuid.v4();
        sessions[id] = {
            brave: new Brave(userSetting),
            log: [],
        }
        setTimeout(function () {
            if (sessions.hasOwnProperty(id)) {
                delete sessions[id];
            }
        }, sessionExpire);

        res.json(new Response(200, "success", {id}))
    } else {
        res.json(new Response(500, "invalid setting"));
    }
});

app.get('/api/battle', function(req, res) {
    let id = req.query.id;
    if (typeof id === 'string' && sessions.hasOwnProperty(id) && sessions[id].brave.status === BraveStatus.Living) {
        let brave = sessions[id].brave;
        let monster = mergeObject(randomChoice(availableMonster), {});
        sessions[id].log = brave.battle(monster);

        res.json(new Response(200, "success", sessions[id]));
    } else {
        res.json(new Response(500, "invalid id"))
    }
});

app.get('/api/battle_peek', function (req, res) {
    let id = req.query.id;

    if (typeof id === 'string' && sessions.hasOwnProperty(id)) {
        res.json(new Response(200, "success", sessions[id]));
    } else {
        res.json(new Response(500, "invalid id"))
    }
});

app.get('/api/report', function (req, res) {
    let id = req.query.id;

    if (typeof id === 'string' && sessions.hasOwnProperty(id)) {
        try {
            let req = http.request(`http://admin:8000/visit?id=${id}`);
            req.on('error', function(err) {
                console.log(err)
            });
            req.end();
        } catch (e) {
            res.json(new Response(500, "report failed"))
            return
        }
        res.json(new Response(200, "success"));
    } else {
        res.json(new Response(500, "invalid id"))
    }
});

app.listen(80, function () {
    chroot("/rootfs", 'nobody', 'nogroup');
});
console.log('Server is listening on port 80');
